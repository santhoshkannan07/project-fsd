import React, { useState } from 'react'
import './listItem.scss'
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import AddIcon from '@mui/icons-material/Add';
import ThumbUpOffAltIcon from '@mui/icons-material/ThumbUpOffAlt';
import ThumbDownOffAltIcon from '@mui/icons-material/ThumbDownOffAlt';

const ListItem = ({index}) => {
    const [isHovered, setIsHovered] = useState(false);
    const trailer = "./videos/woman.mp4"
  return (
    <div 
    className='listItem' 
    style={{left: isHovered && index * 225 - 50 + index * 2.5}}
    onMouseEnter={()=>setIsHovered(true)} 
    onMouseLeave={()=> setIsHovered(false)}
    >

        <img src="https://wallpapercave.com/dwp1x/wp3212747.jpg" alt="" />
        {isHovered && (
            <>
            <video src={trailer} autoPlay={true} loop />
            <div className="itemInfo">
                <div className="icons">
                    <PlayArrowIcon className='icon'/>
                    <AddIcon className='icon'/>
                    <ThumbUpOffAltIcon className='icon'/>
                    <ThumbDownOffAltIcon className='icon'/>
                </div>
                <div className="itemInfoTop">
                    <span>1 hour 14 mins</span>
                    <span className='limit'>+16</span>
                    <span>1999</span>
                </div>
                <div className="desc">
                Movies can be an escape from reality or an inspiration. 
                We often relate to the characters.
                </div>
                <div className="genre">Action</div>
            </div></>
        )}
        
    </div>
  )
}

export default ListItem