import React, { useState } from 'react';
import './navbar.scss';
import SearchIcon from '@mui/icons-material/Search';
import NotificationsIcon from '@mui/icons-material/Notifications';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import { Link } from 'react-router-dom';

const Navbar = () => {
    const[isScrolled, setIsScrolled] = useState(false);

    window.onscroll = ()=>{
        setIsScrolled(window.pageYOffset === 0 ? false : true);
        return ()=> (window.onscroll = null);
    };

    console.log(isScrolled)
  return (
    <div className={isScrolled ? "navbar scrolled" : "navbar"}>
      <div className="container">
        <div className="left">
          <img
            src="https://www.edigitalagency.com.au/wp-content/uploads/netflix-logo-png-large.png"
            alt="Netflix Logo"
          />
          <Link to="/" className='link'>
          <span>Homepage</span>
          </Link>
          <Link to="/series" className='link'>
          <span>Series</span>
          </Link>
          <Link to="/movies" className='link'>
          <span>Movies</span>
          </Link>
          <span>New and Popular</span>
          <span>My List</span>
        </div>
        <div className="right">
            <SearchIcon className='icon'/>
            <span>KID</span>
            <NotificationsIcon className='icon'/>
            <img src="https://imgv3.fotor.com/images/blog-richtext-image/10-profile-picture-ideas-to-make-you-stand-out.jpg"
            alt="" />
            <div className='profile'>
                <ArrowDropDownIcon className='icon'/>
                <div className='options'>
                    <span>Settings</span>
                    <span>Logout</span>
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};

export default Navbar;
